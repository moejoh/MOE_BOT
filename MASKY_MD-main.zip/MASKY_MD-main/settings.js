const settings = {
  packname: '𝐌𝐚𝐬𝐤𝐲_𝐌𝐃',
  author: '𝐌𝐚𝐬𝐤𝐲 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 𝐓𝐞𝐜𝐡',
  botName: "𝗠𝗔𝗦𝗞𝗬 𝗠𝗗",
  botOwner: 'Moe OFFICIAL TECH', // Your name
  ownerNumber: '12136061765', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "private",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "2.1.6",
  updateZipUrl: "https://github.com/MaskyOfficialTech/MASKY_MD/archive/refs/heads/main.zip",
};

module.exports = settings;
